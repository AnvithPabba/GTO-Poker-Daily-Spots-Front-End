# Poker Daily Trainer Contracts

This small package is the public, versioned boundary shared by the frontend
and backend repositories. It contains Zod schemas and TypeScript types for
public spots, legal actions, cards, combos, basis-point submissions, and API
envelopes. It intentionally contains no GTO frequencies, reached ranges,
solver inputs, credentials, or database models.

## Repository boundary

`webapp/contracts` is intended to be its own public Git repository or published
package. Both `webapp/frontend` and the private `webapp/backend` consume the
same version so action IDs and request validation cannot drift.

## Local checks

```bash
pnpm install
pnpm typecheck
pnpm lint
pnpm test
```

The current package is `0.3.1` and exports `CONTRACT_VERSION = 3`. A v3
`PublicSpot` always includes typed known/unknown preflop context,
`featuredCombo`, a 1–20 item
`selectableCombos` catalog containing that featured hand, and neutral
`presentation` metadata, and typed replay events. Known preflop ranges expose
only hand-class inclusion assumptions; postflop reach and strategies remain
private. It deliberately has no `mode` field: the UI renders
the same challenge shell for one or many selected hands. Frequencies,
reached ranges, raw solver fields, and private IDs remain server-only.

Fixtures cover dynamic bet amounts and spots with two, three, and four legal
actions. Every percentage submission is represented as integer basis points
that must total exactly `10_000` for each concrete hand.

Attempts always include the featured combo and may add zero through nineteen
more selectable concrete combos. Each hand has one basis-point allocation per
legal action, totaling exactly `10_000`.

## Docker

Build and run the package test image from this directory:

```bash
docker build -t poker-trainer-contracts:dev .
docker run --rm poker-trainer-contracts:dev
```

The image installs from the committed lockfile, compiles the schemas, and runs
the complete contract fixture suite.

## Release gate

Inspect the exact public contents before a release:

```bash
npm pack --dry-run
```

After an owner-authenticated `npm login`, publish the explicitly reviewed
version (publication is an explicit human approval gate):

```bash
npm publish --access public
```

Do not publish automatically from Docker or CI. The release sequence is
`0.1.0` (v1), `0.2.0` (v2 unified hand model), `0.3.0` (v3 preflop,
daily-game, and attempt-result resources), then `0.3.1` (the additive
`ATTEMPT_INVALIDATED` error code and canonical exact-card ordering validation).
For each release, run `npm pack --dry-run`, inspect the tarball file list and
export map, run the package tests, then obtain explicit publish approval.
Until `0.3.1` is approved and available from npm, frontend/backend use the
generated reviewed tarball in their own `vendor/` directories; neither imports
sibling source or private solution modules.
